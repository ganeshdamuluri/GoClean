<?php
		require_once('class/Template.class.php');

		Template::includeHeader();
		
		Template::includePage();
		
		Template::includeFooter();