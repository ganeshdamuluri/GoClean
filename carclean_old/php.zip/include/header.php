
		<!DOCTYPE html>

		<html>

			<head>

				<title>Mr.Car Clean Go Green</title>
				<meta name="keywords" content="" />
				<meta name="description" content="" />		

				<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
				<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>

				<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700italic,700,900&amp;subset=latin,latin-ext">
				<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=PT+Serif:700italic,700,400italic&amp;subset=latin,cyrillic-ext,latin-ext,cyrillic">
				
				<link rel="stylesheet" type="text/css" href="style/jquery.qtip.css"/>
				<link rel="stylesheet" type="text/css" href="style/jquery-ui.min.css"/>
				<link rel="stylesheet" type="text/css" href="style/superfish.css"/>
				<link rel="stylesheet" type="text/css" href="style/flexnav.css"/>
				<link rel="stylesheet" type="text/css" href="style/DateTimePicker.min.css"/>
				<link rel="stylesheet" type="text/css" href="style/fancybox/jquery.fancybox.css"/> 
				<link rel="stylesheet" type="text/css" href="style/fancybox/helpers/jquery.fancybox-buttons.css"/>
				<link rel="stylesheet" type="text/css" href="style/revolution/layers.css"/> 
				<link rel="stylesheet" type="text/css" href="style/revolution/settings.css"/> 
				<link rel="stylesheet" type="text/css" href="style/revolution/navigation.css"/> 
				<link rel="stylesheet" type="text/css" href="style/base.css"/> 
				<link rel="stylesheet" type="text/css" href="style/responsive.css"/> 
				
				<script type="text/javascript" src="script/jquery.min.js"></script>

			</head>

			<body class="<?php echo Template::getBodyCSSClass(); ?>">